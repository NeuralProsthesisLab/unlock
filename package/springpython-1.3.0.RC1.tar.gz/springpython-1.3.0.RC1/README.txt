To install this package, just run:

python setup.py install


This may require admin privileges. An alternative is to specify a different
location and make sure that location is in your PYTHON_PATH.
