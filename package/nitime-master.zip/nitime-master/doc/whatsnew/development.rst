
============================
 Release notes: development
============================

These are the development release notes. As features are added to nitime and
fixes are made, this is the place to document the broad overview of these
features and fixes, so that they can be included in the release notes for the
next version. 
