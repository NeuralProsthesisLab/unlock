=============
 Nitime news
=============

June 19 2012: Version 0.4 released.

August 13 2011: Version 0.3 released. 

November 9 2010: Version 0.2 released. 

August 18 2010: Nitime version 0.1 is officially out.

Scipy 2009 conference paper `available <_static/Scipy2009Nitime.pdf>`_
