======================
 Nitime Documentation
======================

.. htmlonly::

   :Release: |version|
   :Date: |today|

Contents:

.. toctree::
   :maxdepth: 2

   users/index
   whatsnew/index   
   examples/index
   discussion/index
   devel/index
   api/index
