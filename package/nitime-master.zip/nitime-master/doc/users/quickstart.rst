============
 Quickstart
============

If you have never used python for anything and are interested in trying out
nitime, you can quickly get up and running, by following these 3 steps:

- Install the EPD: The Enthought Python Distribution contains all the
  dependencies for using nitime and can be downloaded from here (free for
  academics):
  http://www.enthought.com/products/getepd.php  

- Use *easy install* to get nitime: Open a terminal window and enter::


      easy_install --user nitime


- Look at the :ref:`examples`.
