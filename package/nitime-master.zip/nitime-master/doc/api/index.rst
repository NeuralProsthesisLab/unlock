.. _api-index:

#####
 API
#####

:Release: |version|
:Date: |today|

.. include:: generated/gen.rst
