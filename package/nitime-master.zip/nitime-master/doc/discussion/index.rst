============
 Discussion
============

This section discusses features which are under active development and not yet
fully implemented. 

Contents:

.. toctree::
   :maxdepth: 2

   note_about_discussion		
   multitaper_jackknife
