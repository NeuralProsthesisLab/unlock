===========
 Use Cases
===========

Below are some usecases written to demonstrate proposed APIs during
development.  This should be converted into end user documentation
examples prior to our next release.
