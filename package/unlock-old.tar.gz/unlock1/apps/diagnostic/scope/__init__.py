from .time import TimeScope
from .frequency import SpectrumScope
