from apps.diagnostic.selector.selector import FreqButton
