from .scope import TimeScope, SpectrumScope
from .selector import FreqButton
