from hsd import HSD
from cca import CCA
#from hsd2 import HSD2
#from hsd2_baselineremoval import HsdBaselineRemoval