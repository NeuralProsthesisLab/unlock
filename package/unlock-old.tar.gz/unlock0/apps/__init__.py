from dashboard import Dashboard
from scope import TimeScope, SpectrumScope
from helloworld import HelloWorld
from freqButton import FreqButton