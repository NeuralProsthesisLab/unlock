from lines import Line1
from rectangles import Rectangle1, Rectangle2, Rectangle3
from text import Text1, Text2