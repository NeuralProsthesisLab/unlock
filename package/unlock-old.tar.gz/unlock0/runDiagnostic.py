from core import Screen, fft_Decoder
from apps import  TimeScope, SpectrumScope, FreqButton
from stimuli import SSVEP, SSVEPStimulus


def get_apps(window):
    """Retrieves apps for viewport

    Partitions window into sections. Apps and stimuli are added to each section

    :param window: window to use to display apps
    """

    w2 = window.width / 2       #Half the width
    h2 = window.height / 2      #Half the height
    bottom_left = Screen(0, 0, w2, h2)
    bottom_right = Screen(w2, 0, w2, h2)
    top_left = Screen(0, h2, w2, h2)
    top_right = Screen(w2, h2, w2, h2)

    debug   = False
    fs      = 256       #sampling frequency
    dur     = 2         #length of sampling time
    numchan = 3         #number of recording channels

    freqs = [11.5,12.0,12.5,13.0,13.5,  #Stimulating frequencies
             14.0,14.5,15.0,15.5,16.0]

    #the decoder to be used on the frequency scope
    decoder = fft_Decoder(fs ,dur, freqs, ffWin=0.1, h1Win=0.1, lpass=8.0, hpass=34.0)

    stim_freq = 10      #Number of checks on one edge
    stim_size = 300     #Size of stimulus in pixels
    stimuli = [
        SSVEPStimulus(bottom_left, 12.0, 'center', width=stim_size,
            height=stim_size, x_freq=stim_freq, y_freq=stim_freq),
        ]
    #SSVEP Stimulus
    app1 = SSVEP(bottom_left, stimuli, rest_length=0)
    #Frequency Scope
    app2 = SpectrumScope(bottom_right, numchan=numchan, dur=dur, debug=debug, decoder=decoder)
    # Time Scope
    app3 = TimeScope(top_right, numchan=numchan, debug=debug)
    #Frequency Selector
    app4 = FreqButton(top_left, freqs, app1 ,app2)

    return [app1, app2, app3, app4]

if __name__ == '__main__':
    from core import viewport
    viewport.controller.apps = get_apps(viewport.window)
    viewport.start()