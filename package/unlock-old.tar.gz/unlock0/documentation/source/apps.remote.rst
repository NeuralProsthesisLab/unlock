remote Package
==============


:mod:`remote` Module
--------------------

.. automodule:: apps.remote.remote
    :members:
    :undoc-members: name
    :show-inheritance:

