Core.application()
====================

:mod:`application` Module
--------------------

.. automodule:: core.application
    :members:
    :undoc-members:
    :show-inheritance: