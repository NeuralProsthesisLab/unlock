stimulus.py Tutorial
==================

So the last thing to go over is the Stimulus.
This is module may not be useful for people looking just to make applications,
but the stimulus is very important for users who want to run experiments with SSVEP.

The stimulus for SSVEP is a flashing checkerboard pattern.
The module is kept in the stimulus folder and can be called in the runtime script,
just as any app would be.

More of this to come soon!