BCI Applications
==================

.. toctree::
   :maxdepth: 2

   apps.freqButton.rst
   apps.helloworld.rst
   apps.remote.rst
   apps.scope.rst
