import pyglet

window = pyglet.window.Window()
label = pyglet.text.Label('Hello, world', font_name='Times New Roman',
		font_size=36, x=window.width//2, y=window.height//2, anchor_x='center', anchor_y='center')
label1 = pyglet.text.HTMLLabel('<font face="Times New Roman" size="4">Hello, <i>world</i></font>',
        x=window.width//2+100, y=window.height//2+100, anchor_x='center', anchor_y='center')
@window.event
def on_draw():
	window.clear()
	label.draw()
	label1.draw()
pyglet.app.run()


