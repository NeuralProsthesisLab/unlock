// gMOBIlabapplDlg.cpp : implementation file
//

#include "stdafx.h"
#include "gMOBIlabplusPCdemo.h"
#include "gMOBIlabplusPCdemoDlg.h"
#include "Config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

USHORT BUFFERLENGTH = 1080;
int DATA_POINTS;
BOOL restart;
int NumOfChannels = 9;
ULONG WINAPI DataAcqTh(void *pArg);
ULONG WINAPI DataDrawTh(void *pArg);

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CgMOBIlabapplDlg dialog




CgMOBIlabapplDlg::CgMOBIlabapplDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CgMOBIlabapplDlg::IDD, pParent)
{
	m_Stream2SD = FALSE;
	m_in1 = FALSE;
	m_in2 = FALSE;
	m_in3 = FALSE;
	m_in4 = FALSE;
	m_out1 = FALSE;
	m_out2 = FALSE;
	m_out3 = FALSE;
	m_out4 = FALSE;
	caption = "g.MOBIlab+ Demo";
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CgMOBIlabapplDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMPORT, m_cbPort);
	DDX_Control(pDX, IDC_CHANNEL, m_cbChanSel);
	DDX_Control(pDX, IDC_SCALING, m_cbScale);
	DDX_Control(pDX, IDC_NTGRAPHCTRL1, m_Display);
	DDX_Check(pDX, IDC_TESTMODE, m_Testmode);
	DDX_Check(pDX, IDC_STREAM2SD, m_Stream2SD);
	DDX_Check(pDX, IDC_WRITEFILE, m_Write2File);
	DDX_Check(pDX, IDC_IN1, m_in1);
	DDX_Check(pDX, IDC_IN2, m_in2);
	DDX_Check(pDX, IDC_IN3, m_in3);
	DDX_Check(pDX, IDC_IN4, m_in4);
	DDX_Check(pDX, IDC_OUT1, m_out1);
	DDX_Check(pDX, IDC_OUT2, m_out2);
	DDX_Check(pDX, IDC_OUT3, m_out3);
	DDX_Check(pDX, IDC_OUT4, m_out4);
	DDX_Control(pDX, IDC_FILENAME, m_Filename);
}

BEGIN_MESSAGE_MAP(CgMOBIlabapplDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPENDEV, OnBOpen)
	ON_BN_CLICKED(IDC_CLOSEDEV, OnBClose)
	ON_BN_CLICKED(IDC_STARTACQ, OnBStart)
	ON_BN_CLICKED(IDC_STOPACQ, OnBStop)
	ON_BN_CLICKED(IDC_PAUSEXFER, OnBPause)
	ON_BN_CLICKED(IDC_RESUMEXFER, OnBResume)
	ON_BN_CLICKED(IDC_UPDATE, OnBUpdate)
	ON_BN_CLICKED(IDC_SHOWCONFIG, OnBShowConfig)
	ON_CBN_CLOSEUP(IDC_SCALING, OnCloseupScale)
	//}}AFX_MSG_MAP	
END_MESSAGE_MAP()


// CgMOBIlabapplDlg message handlers

BOOL CgMOBIlabapplDlg::OnInitDialog()
{
	//Called at dialog initialization

	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//initialize the list box with the COM ports and the display
	
	CString str;
	m_cbPort.ResetContent();
	for (int i=0;i<256;i++)
	{
		str.Format(L"COM%i:",i+1);
		m_cbPort.AddString(str);
		m_cbPort.SetItemData(i,i+1);
	}

	m_cbPort.SetCurSel(0);
	m_cbChanSel.SetCurSel(0);
	m_cbScale.SetCurSel(0);

	m_Scale = 100;

	m_Display.SetCaption(L" ");
	InitDisplay(250);
	GetDlgItem(IDC_UPDATE)->EnableWindow(FALSE);
	_isrunning = FALSE;
	_isdrawing = FALSE;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CgMOBIlabapplDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CgMOBIlabapplDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CgMOBIlabapplDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CgMOBIlabapplDlg::OnBOpen()
{
	//Function called when the Open button is clicked

	BOOL ret = FALSE;
	UINT * ErrCode = new UINT;
	int i = 0;
	CString portstr;
	size_t c;
	HANDLE hDevice = NULL;
	__DEVICESTATE * DevStatus = new __DEVICESTATE;
	char ser = 'M';
	char str[3];
	UINT * CardSize = new UINT[sizeof(UINT)];
	__CFG * config = new __CFG;
	CString cfgcapt;

	GetDlgItem(IDC_OPENDEV)->EnableWindow(FALSE);

	i = m_cbPort.GetCurSel();
	m_cbPort.GetLBText(i,portstr);
	portstr.Insert(0,L"\\\\.\\");
	i = portstr.GetLength();
	portstr.Insert(i-1,L'\0');
	char * prtadd = new char[i];
	wcstombs_s(&c,prtadd,i,portstr.GetString(),i);

	//open the connnection to g.MOBIlab+
	hDevice = GT_OpenDevice(prtadd);

	if (hDevice == NULL)
	{
		ErrorHandling();
		GetDlgItem(IDC_OPENDEV)->EnableWindow(TRUE);
		return;
	}

	m_hDevice = hDevice;

	
	str[0] = '0';
	str[1] = '1';
	str[2] = 's';
	
	//get the size of the SDcard. If none is inserted,
	//Stream to SD is disabled
	ret = GT_GetSDcardStatus(m_hDevice, CardSize);
	if (!ret)
	{
		CloseHandle(m_hDevice);
		m_hDevice = NULL;
		GetDlgItem(IDC_OPENDEV)->EnableWindow(TRUE);
		ErrorHandling();
		return;
	}

	if (*CardSize != 0)
	{
		GetDlgItem(IDC_STREAM2SD)->EnableWindow(TRUE);
	}
	else
	{
		CheckDlgButton(IDC_STREAM2SD,BST_UNCHECKED);
		GetDlgItem(IDC_STREAM2SD)->EnableWindow(FALSE);
	}
	
	//get the status of the device, to see if device is running
	ret = GT_GetDeviceStatus(m_hDevice, DevStatus);
	if (!ret)
	{
		GT_GetLastError(ErrCode);
		if (*ErrCode == 16)
		{}
		else
		{
			CloseHandle(m_hDevice);
			m_hDevice = NULL;
			GetDlgItem(IDC_OPENDEV)->EnableWindow(TRUE);
			ErrorHandling();
			return;
		}
	}

	if (DevStatus->serial[0] == ser)
	{
		if ((DevStatus->SDstate == str[0]) || (DevStatus->SDstate == str[1]))
		{
			GetDlgItem(IDC_CLOSEDEV)->EnableWindow(TRUE);
			GetDlgItem(IDC_STARTACQ)->EnableWindow(TRUE);
			GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
			GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
			GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);
		}

		if (DevStatus->SDstate == str[1])
		{
			GetDlgItem(IDC_STREAM2SD)->EnableWindow(TRUE);
		}

		if (DevStatus->SDstate == str[2])
		{
			GetDlgItem(IDC_CLOSEDEV)->EnableWindow(TRUE);
			GetDlgItem(IDC_STARTACQ)->EnableWindow(FALSE);
			GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
			GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
			GetDlgItem(IDC_RESUMEXFER)->EnableWindow(TRUE);
		}
	}
	else
	{
		GetDlgItem(IDC_CLOSEDEV)->EnableWindow(TRUE);
		GetDlgItem(IDC_STARTACQ)->EnableWindow(TRUE);
		GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
		GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
		GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);
	}

	m_hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	m_DataDrawnow = CreateEvent(NULL,FALSE,FALSE,NULL);
	
	GetDlgItem(IDC_SHOWCONFIG)->EnableWindow(TRUE);
	GetDlgItem(IDC_COMPORT)->EnableWindow(FALSE);
	
	
	CWnd *pWnd = GetDlgItem(IDD_GMOBILABAPPL_DIALOG);

	//read config to print serial number on the diagram
	ret = GT_GetConfig(m_hDevice, config);
	if (!ret)
	{
		CloseHandle(m_hDevice);
		m_hDevice = NULL;
		GetDlgItem(IDC_OPENDEV)->EnableWindow(TRUE);
		ErrorHandling();
		return;
	}

	cfgcapt = config->serial;

	m_Display.SetCaption(cfgcapt);

	for (i=0;i<8;i++)
	{
		m_ChanScale[i] = config->channels[i].sensitivity;
	}
	delete config;
	delete DevStatus;
	delete CardSize;
	delete prtadd;
	delete ErrCode;

}

void CgMOBIlabapplDlg::OnBClose()
{
	//function called when the Close button is clicked

	BOOL ret = FALSE;

	if (_isrunning)
	{
		CString message;
		message = "Stop acquisition first";
		MessageBox(message.GetBuffer(),caption.GetBuffer(),MB_OK | MB_ICONERROR);
		return;
	}
	
	//Close the connection to g.MOBIlab+
	ret = GT_CloseDevice(m_hDevice);
	if (!ret)
	{
		ErrorHandling();
		return;
	}

	m_hDevice = NULL;
	CloseHandle(m_hEvent);
	CloseHandle(m_DataDrawnow);

	CheckDlgButton(IDC_STREAM2SD,BST_UNCHECKED);

	GetDlgItem(IDC_CLOSEDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_OPENDEV)->EnableWindow(TRUE);
	GetDlgItem(IDC_STARTACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_SHOWCONFIG)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMPORT)->EnableWindow(TRUE);
	GetDlgItem(IDC_STREAM2SD)->EnableWindow(FALSE);

}

void CgMOBIlabapplDlg::OnBStart()
{
	//function called when the Start button is clicked

	BOOL ret;
	_AIN aCh;
	_DIO dCh;
	CString str;
	int length,i;
	size_t c;
	char headerstart[600];
	char * filename = new char[9];
	__CFG * cfg = new __CFG;
	
	//set the channels used and the directions of the DIOS
	aCh.ain1 = TRUE;
	aCh.ain2 = TRUE;
	aCh.ain3 = TRUE;
	aCh.ain4 = TRUE;
	aCh.ain5 = TRUE;
	aCh.ain6 = TRUE;
	aCh.ain7 = TRUE;
	aCh.ain8 = TRUE;

	dCh.dio1_enable = TRUE;
	dCh.dio2_enable = TRUE;
	dCh.dio3_enable = TRUE;
	dCh.dio4_enable = TRUE;
	dCh.dio5_enable = TRUE;
	dCh.dio6_enable = TRUE;
	dCh.dio7_enable = TRUE;
	dCh.dio8_enable = TRUE;

	dCh.dio4_direction = FALSE;
	dCh.dio5_direction = FALSE;
	dCh.dio6_direction = FALSE;
	dCh.dio7_direction = FALSE;
	
	UpdateData(TRUE);

	GetDlgItem(IDC_SHOWCONFIG)->EnableWindow(FALSE);
	
	m_DispChannel = m_cbChanSel.GetCurSel();
	
	//get the filename provided in the textbox
	m_Filename.GetWindowTextW(str);
	length = str.GetLength();
	if (length>8)
	{
		CString message;
		message = "Number of characters in Filename > 8.";
		MessageBox(message.GetBuffer(),caption.GetBuffer(),MB_OK | MB_ICONERROR);
		return;
	}
	else if ((length==0)&&(m_Stream2SD)) 
	{
		CString message;
		message = "No filename provided.";
		MessageBox(message.GetBuffer(),caption.GetBuffer(),MB_OK | MB_ICONERROR);
		return;
	}
	
	wcstombs_s(&c,filename,9,str.GetString(),9);
	
	//Set device to testmode if selected
	ret = GT_SetTestmode(m_hDevice, m_Testmode);
	if (!ret)
	{
		ErrorHandling();
		return;
	}
	
	//Enable the SDcard if inserted into g.MOBIlab+
	ret = GT_EnableSDcard(m_hDevice, m_Stream2SD);
	if ((!ret)&&(m_Stream2SD))
	{
		ErrorHandling();
		return;
	}
	if(m_Stream2SD)
	{
		//Set the filename for the file recorded to SD card
		ret = GT_SetFilename(m_hDevice, filename, length);
		if (!ret)
		{
			ErrorHandling();
			return;
		}
	}
	delete filename;

	//Set Filename to write data to file
	if (m_Write2File)
	{
		CString filestr;
		CString fileext;
		CString fileopt;
		CString defFilename;
		CString filedir;
		defFilename = "gMOBIlabData.bin";
		fileopt = "g.MOBIlab+ Files (*.bin)|*.bin||";
		fileext = "bin";
		filedir = "C:\\";
		CFileDialog Filename(FALSE,fileext,defFilename,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,fileopt,NULL,0);
		CFileException fileException;

		Filename.GetOFN().lpstrInitialDir = filedir;

		if (Filename.DoModal() == IDOK)
		{
			filestr = Filename.GetPathName();
			if (!DataFile.Open(filestr, DataFile.modeCreate | DataFile.modeWrite, &fileException))
			{
				CString message;
				message = "Can not open selected file";
				MessageBox(message.GetBuffer(),caption.GetBuffer(),MB_OK | MB_ICONERROR);
			}
		}
		else
		{
			CString message;
			message = "No file selected";
			MessageBox(message.GetBuffer(),caption.GetBuffer(),MB_OK|MB_ICONERROR);
			return;
		}
		
		//read config to write it to the bin file header
		ret = GT_GetConfig(m_hDevice,cfg);
		if(!ret)
		{
			DataFile.Close();
			ErrorHandling();
			return;
		}

		length = sprintf_s(headerstart,sizeof("gtec\r\ngMOBIlab+\r\n3.0\r\n256\r\n"),"gtec\r\ngMOBIlab+\r\n3.0\r\n256\r\n");
		
		length += sprintf_s(headerstart + length,sizeof("%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i\r\n%i\r\n%i\r\n%d\r\n%s\r\n"),
			"%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i%i\r\n%i\r\n%i\r\n%d\r\n%s\r\n",
			aCh.ain8,aCh.ain7,aCh.ain6,aCh.ain5,aCh.ain4,aCh.ain3,aCh.ain2,aCh.ain1,
			dCh.dio8_enable,dCh.dio7_enable,dCh.dio6_enable,dCh.dio5_enable,
			dCh.dio4_enable,dCh.dio3_enable,dCh.dio2_enable,dCh.dio1_enable,
			1,dCh.dio7_direction,dCh.dio6_direction,dCh.dio5_direction,dCh.dio4_direction,1,1,1,
			3,2,cfg->version,cfg->serial);

		for (i=0;i<8;i++)
		{
			length += sprintf_s(headerstart + length,50,
				"%g/%g/%g/%g/%c\r\n",cfg->channels[i].highpass,
				cfg->channels[i].lowpass,cfg->channels[i].sensitivity,
				cfg->channels[i].samplerate,cfg->channels[i].polarity);
		}
		
		length += sprintf_s(headerstart + length,sizeof("EOH\r\n"),"EOH\r\n");
		DataFile.Write(headerstart,(UINT)strlen(headerstart));
	}
	
	//initialize the channels set to be recorded
	ret = GT_InitChannels(m_hDevice, aCh, dCh);
	if (!ret)
	{
		ErrorHandling();
		return;
	}

	//set the display to be have width of 540 datapoints
	int dispPoints = 540;
	InitDisplay(dispPoints);
	
	restart = FALSE;
	_isrunning = TRUE;
	_isdrawing = TRUE;

	//create worker threads to record and draw data
	m_hDataAcqTh = CreateThread(	NULL,// pointer to security attributes
								0,// initial thread stack size
								DataAcqTh,// pointer to thread function
								this,// argument for new thread
								CREATE_SUSPENDED,// creation flags
								  &_tid);// pointer to receive thread ID
	SetThreadPriority(m_hDataAcqTh, THREAD_PRIORITY_TIME_CRITICAL ); //THREAD_PRIORITY_HIGHEST

	m_hDataDrawTh = CreateThread(	NULL,// pointer to security attributes
								0,// initial thread stack size
								DataDrawTh,// pointer to thread function
								this,// argument for new thread
								CREATE_SUSPENDED,// creation flags
								  &_tid);// pointer to receive thread ID
	SetThreadPriority(m_hDataDrawTh, THREAD_PRIORITY_ABOVE_NORMAL );

	
	pfDrawBuffer = NULL;
	ResumeThread(m_hDataDrawTh); // start this thread first
	ResumeThread(m_hDataAcqTh);

	GetDlgItem(IDC_CLOSEDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_OPENDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STARTACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOPACQ)->EnableWindow(TRUE);
	GetDlgItem(IDC_UPDATE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHANNEL)->EnableWindow(FALSE);
	GetDlgItem(IDC_SCALING)->EnableWindow(FALSE);
	GetDlgItem(IDC_WRITEFILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_STREAM2SD)->EnableWindow(FALSE);
	GetDlgItem(IDC_FILENAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_TESTMODE)->EnableWindow(FALSE);
	
	if(m_Stream2SD)
	{
		GetDlgItem(IDC_PAUSEXFER)->EnableWindow(TRUE);
	}
	else
	{
		GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
	}
	GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);

}

ULONG WINAPI DataAcqTh(void *pArg)
{
	//Worker thread to record data
	CgMOBIlabapplDlg *applptr = (CgMOBIlabapplDlg*) pArg;
	BOOL ret = FALSE;
	short buffer[540];
	OVERLAPPED ov;
	DWORD dwBytesReceived;
	short *pfl = NULL;
	int dispChannel = 0;

	ov.hEvent = applptr->m_hEvent;
	ov.Offset = 0;
	ov.OffsetHigh = 0;
	
	short *pDrawBuffer = new short[BUFFERLENGTH/2];
	_BUFFER_ST datbuffer;

	applptr->pfDrawBuffer = pDrawBuffer;
	datbuffer.validPoints = 0;
	datbuffer.size = sizeof(buffer);
	datbuffer.pBuffer = &buffer[0];

	if (!restart)
	{
		//Start data acqusition
		ret = GT_StartAcquisition(applptr->m_hDevice);
		if (ret == FALSE)
		{
			applptr->ErrorHandling();
			return 0xdead;
		}
	}

	while (applptr->_isrunning)
	{
		//retrieve data from g.MOBIlab+
		ret = GT_GetData(applptr->m_hDevice, &datbuffer, &ov);
		WaitForSingleObject(applptr->m_hEvent,1000);
		GetOverlappedResult(applptr->m_hDevice,&ov,&dwBytesReceived,FALSE);
		
		datbuffer.validPoints = dwBytesReceived/2;

		if (!ret || (dwBytesReceived != datbuffer.size))
		{
			applptr->SendDlgItemMessage(IDC_STOPACQ,BN_CLICKED,0,0);
			applptr->_isrunning = FALSE;
			break;
		}
		//write data to the file on the PC
		if (applptr->m_Write2File)
		{
			applptr->DataFile.Write(buffer,sizeof(buffer));
		}
		
		//set buffer to draw the selected channel
		//and set digital channel data
		dispChannel = applptr->m_DispChannel;
		for (int i=0;i<BUFFERLENGTH/2/NumOfChannels;i++)
		{
			pfl = &buffer[dispChannel + i*NumOfChannels];
			pDrawBuffer[i] = *pfl;
			buffer[8+9*(i-1)] & 0x0001 ? applptr->in1 = TRUE : applptr->in1 = FALSE;
			buffer[8+9*(i-1)] & 0x0008 ? applptr->in2 = TRUE : applptr->in2 = FALSE;
			buffer[8+9*(i-1)] & 0x0002 ? applptr->in3 = TRUE : applptr->in3 = FALSE;
			buffer[8+9*(i-1)] & 0x0080 ? applptr->in4 = TRUE : applptr->in4 = FALSE;
		}
		
		//Call draw thread
		SetEvent(applptr->m_DataDrawnow);

		
	}

	delete[] pDrawBuffer;
	applptr->pfDrawBuffer = NULL;
	applptr->DataFile.Abort();

	return 0xdead;

}

ULONG WINAPI DataDrawTh (void *pArg)
{
	//worker thread to draw recorded data
	CgMOBIlabapplDlg *applptr = (CgMOBIlabapplDlg*) pArg;
	int iBytesPerScan;
	DWORD dwResult;

	iBytesPerScan = sizeof(short);

	while (applptr->_isdrawing)
	{
		dwResult = WaitForSingleObject(applptr->m_DataDrawnow,100);
		if (dwResult == WAIT_TIMEOUT)
		{
			continue;
		}
		applptr->PlotData(applptr->pfDrawBuffer,BUFFERLENGTH/iBytesPerScan/NumOfChannels);
	}

	return 0xdead;
}

void CgMOBIlabapplDlg::OnBStop()
{
	//Called when the Stop button is clicked

	_isrunning = FALSE;
	_isdrawing = FALSE;
	
	//stop data acquisition
	GT_StopAcquisition(m_hDevice);
	
	GetDlgItem(IDC_CLOSEDEV)->EnableWindow(TRUE);
	GetDlgItem(IDC_OPENDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STARTACQ)->EnableWindow(TRUE);
	GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_SHOWCONFIG)->EnableWindow(TRUE);
	GetDlgItem(IDC_WRITEFILE)->EnableWindow(TRUE);
	GetDlgItem(IDC_UPDATE)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHANNEL)->EnableWindow(TRUE);
	GetDlgItem(IDC_SCALING)->EnableWindow(TRUE);
	GetDlgItem(IDC_STREAM2SD)->EnableWindow(TRUE);
	GetDlgItem(IDC_FILENAME)->EnableWindow(TRUE);
	GetDlgItem(IDC_TESTMODE)->EnableWindow(TRUE);

}

void CgMOBIlabapplDlg::OnBPause()
{
	//Called when the Pause button is clicked

	BOOL ret;
	
	//Pauses data transfer to the PC
	ret = GT_PauseXfer(m_hDevice);
	if (!ret)
	{
		ErrorHandling();
		return;
	}

	_isrunning = FALSE;
	_isdrawing = FALSE;
	m_Write2File = FALSE;
	UpdateData(FALSE);

	GetDlgItem(IDC_CLOSEDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_OPENDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STARTACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOPACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_PAUSEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_RESUMEXFER)->EnableWindow(TRUE);
	GetDlgItem(IDC_WRITEFILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_UPDATE)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHANNEL)->EnableWindow(TRUE);
	GetDlgItem(IDC_SCALING)->EnableWindow(TRUE);
	GetDlgItem(IDC_TESTMODE)->EnableWindow(TRUE);

}

void CgMOBIlabapplDlg::OnBResume()
{
	//Called when Resume button is clicked

	BOOL ret;
	UpdateData(TRUE);

	m_DispChannel = m_cbChanSel.GetCurSel();
	
	int dispPoints = 540;
	InitDisplay(dispPoints);
	
	//Resume data transfer to the PC
	ret = GT_ResumeXfer(m_hDevice);
	if (!ret)
	{
		ErrorHandling();
		return;
	}

	restart = TRUE;
	_isrunning = TRUE;
	_isdrawing = TRUE;

	m_hDataAcqTh = CreateThread(	NULL,// pointer to security attributes
								0,// initial thread stack size
								DataAcqTh,// pointer to thread function
								this,// argument for new thread
								CREATE_SUSPENDED,// creation flags
								  &_tid);// pointer to receive thread ID
	SetThreadPriority(m_hDataAcqTh, THREAD_PRIORITY_TIME_CRITICAL ); //THREAD_PRIORITY_HIGHEST

	m_hDataDrawTh = CreateThread(	NULL,// pointer to security attributes
								0,// initial thread stack size
								DataDrawTh,// pointer to thread function
								this,// argument for new thread
								CREATE_SUSPENDED,// creation flags
								  &_tid);// pointer to receive thread ID
	SetThreadPriority(m_hDataDrawTh, THREAD_PRIORITY_ABOVE_NORMAL );

	
	pfDrawBuffer = NULL;
	ResumeThread(m_hDataDrawTh); // start this thread first
	ResumeThread(m_hDataAcqTh);

	GetDlgItem(IDC_CLOSEDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_OPENDEV)->EnableWindow(FALSE);
	GetDlgItem(IDC_STARTACQ)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOPACQ)->EnableWindow(TRUE);
	GetDlgItem(IDC_PAUSEXFER)->EnableWindow(TRUE);
	GetDlgItem(IDC_RESUMEXFER)->EnableWindow(FALSE);
	GetDlgItem(IDC_UPDATE)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHANNEL)->EnableWindow(FALSE);
	GetDlgItem(IDC_SCALING)->EnableWindow(FALSE);
	GetDlgItem(IDC_TESTMODE)->EnableWindow(FALSE);

}

void CgMOBIlabapplDlg::OnBUpdate()
{
	//called when Update button for DIOs is clicked

	BOOL ret;
	UCHAR Diout = 0;

	UpdateData(TRUE);

	m_in1 = in1;
	m_in2 = in2;
	m_in3 = in3;
	m_in4 = in4;

	if (m_out1)
	{
		Diout += 136;
	}
	else if (!m_out1)
	{
		Diout +=128;
	}
	if (m_out2)
	{
		Diout += 68;
	}
	else if (!m_out2)
	{
		Diout += 64;
	}
	if (m_out3)
	{
		Diout += 34;
	}
	else if (!m_out3)
	{
		Diout +=32;
	}
	if (m_out4)
	{
		Diout += 17;
	}
	else if (!m_out4)
	{
		Diout += 16;
	}
	
	//set values to selected digital outputs
	ret = GT_SetDigitalOut(m_hDevice, Diout);
	if(!ret)
	{
		ErrorHandling();
		return;
	}
	
	UpdateData(FALSE);
}

void CgMOBIlabapplDlg::OnCloseupScale()
{
	//Called when Scaling is selected

	int i;
	CString str;
	
	UpdateData(TRUE);

	i = m_cbScale.GetCurSel();
	m_cbScale.GetLBText(i,str);

	if(str == "+/- 100uV")
		m_Scale = 100;
	else if(str == "+/- 500uV")
		m_Scale = 500;
	else if(str == "+/- 2mV")
		m_Scale = 2000;
	else if(str == "+/- 5mV")
		m_Scale = 5000;
	else if(str == "+/- 50mV")
		m_Scale = 50000;
	else if(str == "+/- 500mV")
		m_Scale = 500000;
	else if(str == "+/- 5V")
		m_Scale = 5000000;

	InitDisplay(250);

}

void CgMOBIlabapplDlg::InitDisplay(int iNumberOfPoints)
{
	//called to set display labels and scaling

	DATA_POINTS = iNumberOfPoints;
	CString str;
	
	if (m_Scale < 0)
		m_Scale = 100;

	m_Display.ClearGraph();
	m_Display.SetGridColor(RGB(128,128,128));
	m_Display.SetElementLineColor(RGB(255,255,255));
	str = "Samples [n]";
	m_Display.SetXLabel(str.GetBuffer());

	if (!m_Testmode)
	{
		str = "U [V]";
		if (m_Scale < 1000000)
		{
			if (m_Scale < 1000)
				str.Insert(3,0xB5);
			else
				str.Insert(3,0x6D);
		}
		m_Display.SetYLabel(str);
		str = "%gV";
		m_Display.SetRange(0.0,DATA_POINTS*1.0,m_Scale*(-1),m_Scale);
		str.Insert(2,0xB5);
		m_Display.SetFormatAxisLeft(str);
		m_Display.SetYGridNumber(4);
		m_Display.SetXGridNumber(4);
		m_Display.SetTrackMode(5);
	}
	else
	{
		str = "";
		m_Display.SetYLabel(str);
		m_Display.SetRange(0.0,DATA_POINTS*1.0,-32768,32768);
		str = "%g";
		m_Display.SetFormatAxisLeft(str);
		m_Display.SetYGridNumber(4);
		m_Display.SetXGridNumber(4);
		m_Display.SetTrackMode(5);
	}

	for (int i=0;i<DATA_POINTS;i++)
	{
		m_Display.PlotXY(i,0.0,0);
	}

}

void CgMOBIlabapplDlg::PlotData(short *pData, int iSize)
{
	//plot data to the graph of g.MOBIlabPCdemo.exe
	
	static int index = 0;
	float drawvalue = 0;
	float scale = 0;
	int cnt;

	if (pData == 0)
		return;

	scale = (5*2*m_ChanScale[m_DispChannel])/(4*65536);

	for (cnt=0;cnt<iSize;cnt++)
	{
		if (!m_Testmode)
			drawvalue = (float)(*(pData+cnt)*scale);
		else
			drawvalue = (float)(*(pData+cnt));

		m_Display.SetElementYValue(index,0,drawvalue);
		index++;
		if (index == DATA_POINTS)
			index = 0;
	}
}

void CgMOBIlabapplDlg::OnBShowConfig()
{
	//show the configuration of g.MOBIlab+
	CConfig dlg;

	dlg.pgMOBIlabappl = this;
	dlg.DoModal();
}

BOOL CgMOBIlabapplDlg::ErrorHandling()
{
	//Called if an error occured in the demo program
	UINT i = 0;
	BOOL ret;
	CString ErrorStr;
	_ERRSTR strError;

	ret = GT_GetLastError(&i); // get number of last error
	GT_TranslateErrorCode(&strError,i); // get corresponding error string

	ErrorStr = strError.Error;
	MessageBox(ErrorStr,caption.GetBuffer(),MB_OK | MB_ICONERROR);

	return TRUE;
}
	