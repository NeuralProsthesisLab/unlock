// gMOBIlabapplDlg.h : header file
//
#include "ntgraph.h"

#pragma once


// CgMOBIlabapplDlg dialog
class CgMOBIlabapplDlg : public CDialog
{
// Construction
public:
	CgMOBIlabapplDlg(CWnd* pParent = NULL);	// standard constructor
	void PlotData(short *pData, int iSize);
	void InitDisplay(int iNumberOfPoints);
	CString caption;
	BOOL ErrorHandling();
	HANDLE m_hDevice;
	HANDLE m_hEvent;
	HANDLE m_hDataAcqTh;
	HANDLE m_hDataDrawTh;
	HANDLE m_DataDrawnow;
	BOOL _isrunning;
	BOOL _isdrawing;
	BOOL m_Stream2SD;
	BOOL m_Write2File;
	BOOL in1;
	BOOL in2;
	BOOL in3;
	BOOL in4;
	ULONG _tid;
	short *pfDrawBuffer;
	DWORD m_DispChannel;
	char m_Port;
	float m_Scale;
	float m_ChanScale[8];

// Dialog Data
	enum { IDD = IDD_GMOBILABAPPL_DIALOG };
	CComboBox m_cbPort;
	CComboBox m_cbChanSel;
	CComboBox m_cbScale;
	CEdit m_Filename;
	CFile DataFile;
	CNTGraph m_Display;
	BOOL m_Testmode;
	BOOL m_in1;
	BOOL m_in2;
	BOOL m_in3;
	BOOL m_in4;
	BOOL m_out1;
	BOOL m_out2;
	BOOL m_out3;
	BOOL m_out4;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBOpen();
	afx_msg void OnBClose();
	afx_msg void OnBStart();
	afx_msg void OnBStop();
	afx_msg void OnBPause();
	afx_msg void OnBResume();
	afx_msg void OnBUpdate();
	afx_msg void OnCloseupPort();
	afx_msg void OnCloseupScale();
	afx_msg void OnBShowConfig();
	DECLARE_MESSAGE_MAP()
};
