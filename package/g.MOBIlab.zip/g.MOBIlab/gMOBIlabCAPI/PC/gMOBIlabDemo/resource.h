//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by gMOBIlabplusPCdemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GMOBILABAPPL_DIALOG         102
#define IDR_MAINFRAME                   129
#define IDD_CONFIG                      132
#define IDC_OPENDEV                     1007
#define IDC_PAUSEXFER                   1008
#define IDC_STARTACQ                    1009
#define IDC_STOPACQ                     1010
#define IDC_CLOSEDEV                    1011
#define RESUMEXFER                      1012
#define IDC_RESUMEXFER                  1012
#define IDC_COMPORT                     1013
#define IDC_TESTMODE                    1014
#define IDC_CHANNEL                     1016
#define IDC_SCALING                     1017
#define IDC_FILENAME                    1018
#define IDC_RICHEDIT21                  1020
#define IDC_NTGRAPHCTRL1                1021
#define IDC_STREAM2SD                   1024
#define IDC_IN1                         1025
#define IDC_IN2                         1026
#define IDC_IN3                         1027
#define IDC_IN4                         1028
#define IDC_OUT1                        1029
#define IDC_OUT2                        1030
#define IDC_OUT3                        1031
#define IDC_OUT4                        1032
#define IDC_UPDATE                      1037
#define IDC_CONFIGDISP                  1038
#define IDC_CLOSEDLG                    1039
#define IDC_SAVECONFIG                  1040
#define IDC_SHOWCONFIG                  1044
#define IDC_CHECK1                      1045
#define IDC_WRITEFILE                   1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
