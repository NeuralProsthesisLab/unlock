// Config.cpp : implementation file
//

#include "stdafx.h"
#include "gMOBIlabplusPCdemo.h"
#include "Config.h"
#include "afx.h"
#include "afxdlgs.h"

// CConfig dialog

IMPLEMENT_DYNAMIC(CConfig, CDialog)

CConfig::CConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CConfig::IDD, pParent)
{

}

CConfig::~CConfig()
{
}

void CConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CONFIGDISP, m_Config);
}


BEGIN_MESSAGE_MAP(CConfig, CDialog)
	ON_BN_CLICKED(IDC_CLOSEDLG, OnBCloseDlg)
	ON_BN_CLICKED(IDC_SAVECONFIG, OnBSaveConfig)
END_MESSAGE_MAP()


// CConfig message handlers
BOOL CConfig::OnInitDialog()
{
	//Function called on initialization of Config dialog
	CDialog::OnInitDialog();
	BOOL ret;
	float Dversion;
	__CFG * config = new __CFG;
	HANDLE hDevice;

	hDevice = pgMOBIlabappl->m_hDevice;

	//read configuration of gMOBIlab+
	ret = GT_GetConfig(hDevice, config); 
	if (!ret)
	{
		pgMOBIlabappl->ErrorHandling();
		return FALSE;
	}

	//get the version of the dll and write is to string
	Dversion = GT_GetDriverVersion();

	str.Format(L"Device Version: %i\r\nDriver Version: %g\r\nSerial: %S\r\nChannel Settings:\r\nHP/LP/Polarity/Samplerate/Sensitivity\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g\r\n%g/%g/%c/%g/%g",
		config->version,Dversion,config->serial,
		config->channels[0].highpass,config->channels[0].lowpass,config->channels[0].polarity,config->channels[0].samplerate,config->channels[0].sensitivity,
		config->channels[1].highpass,config->channels[1].lowpass,config->channels[1].polarity,config->channels[1].samplerate,config->channels[1].sensitivity,
		config->channels[2].highpass,config->channels[2].lowpass,config->channels[2].polarity,config->channels[2].samplerate,config->channels[2].sensitivity,
		config->channels[3].highpass,config->channels[3].lowpass,config->channels[3].polarity,config->channels[3].samplerate,config->channels[3].sensitivity,
		config->channels[4].highpass,config->channels[4].lowpass,config->channels[4].polarity,config->channels[4].samplerate,config->channels[4].sensitivity,
		config->channels[5].highpass,config->channels[5].lowpass,config->channels[5].polarity,config->channels[5].samplerate,config->channels[5].sensitivity,
		config->channels[6].highpass,config->channels[6].lowpass,config->channels[6].polarity,config->channels[6].samplerate,config->channels[6].sensitivity,
		config->channels[7].highpass,config->channels[7].lowpass,config->channels[7].polarity,config->channels[7].samplerate,config->channels[7].sensitivity);
	
	m_Config.SetWindowText(str);

	return TRUE;

}
void CConfig::OnBSaveConfig()
{
	//Function called on Save button clicked
	CString filestr; //string holding conplete filepath
	CString fileext; //default file extension for dialog
	CString fileopt; //file description in Save As dialog
	CString defFilename; //default filename
	CString filedir; //default directory
	fileopt = "g.MOBIlab+ Config Files (*.cfg)|*.cfg||";
	defFilename = "gMOBIlabConfig";
	fileext = "cfg";
	filedir = "C:\\";
	CFile ConfigFile;
	//Set file dialog variable to open file dialog
	CFileDialog Filename(FALSE,fileext,defFilename,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,fileopt,NULL,0);
	CFileException fileException;

	Filename.GetOFN().lpstrInitialDir = filedir;

	if (Filename.DoModal() == IDOK)
	{
		filestr = Filename.GetPathName();
		if (!ConfigFile.Open(filestr, ConfigFile.modeCreate | ConfigFile.modeWrite, &fileException))
		{
			CString message;
			message = "Can't open file %s, error = %u";
			MessageBox(message.GetBuffer(),NULL,MB_OK | MB_ICONERROR);
		}
	}
	else
	{
		CString message;
		message = "No File selected";
		MessageBox(message.GetBuffer(),NULL,MB_OK|MB_ICONERROR);
		return;
	}

	UINT len = str.GetLength();
	ConfigFile.Write(str,len*2); //write string to file

}

void CConfig::OnBCloseDlg()
{
	//Close Config dialog
	CConfig::EndDialog(0);
}