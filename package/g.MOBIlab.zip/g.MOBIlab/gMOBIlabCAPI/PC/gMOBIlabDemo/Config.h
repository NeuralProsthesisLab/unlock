#pragma once

#include "gMOBIlabplusPCdemoDlg.h"

// CConfig dialog

class CConfig : public CDialog
{
	DECLARE_DYNAMIC(CConfig)

public:
	CConfig(CWnd* pParent = NULL);   // standard constructor
	CgMOBIlabapplDlg * pgMOBIlabappl;
	CEdit m_Config;
	CString str;
	virtual ~CConfig();

// Dialog Data
	enum { IDD = IDD_CONFIG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnBSaveConfig();
	afx_msg void OnBCloseDlg();

	DECLARE_MESSAGE_MAP()
};
