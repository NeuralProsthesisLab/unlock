function [y,samplingfrequency,version,lowpass,...
    highpass,sens,manu,prodname] = importgMOBIlabplus(filename)
% g.MOBIlab data import function for BIN files
% 
% This function imports the different versions of g.MOBIlab BIN files
% from SD Card and Pocket PC.
% 
% Output of importgMOBIlabplus function:
%
% y....raw data
%
% data is stored in the following order:
%
% <int16 channel 1>       if EEG1 is scanned 
% <int16 channel 2>       if EEG2 is scanned 
% <int16 channel 3>       if EEG3 is scanned  
% <int16 channel 4>       if EEG4 is scanned  
% <int16 channel 5>       if ECG1 is scanned 
% <int16 channel 6>       if ECG2 is scanned 
% <int16 channel 7>       if AIN1 is scanned 
% <int16 channel 8>       if AIN2 is scanned 
% <int16 DIOs     >       if any of the DIO channels is scanned 
% 
% <int16 channel 1>       if EEG1 is scanned 
% <int16 channel 2>       if EEG2 is scanned 
% 
% .
% .
% 
% The values of the digital lines are coded in the bits of int16 digital lines: 
% 
% bit 0:  Digital Input 1
% bit 1:  Digital Input 3 (external switch)
% bit 2:  DIO1      
% bit 3:  Digital Input 2
% bit 4:  DIO2
% bit 5:  DIO3
% bit 6:  DIO4
% bit 7:  Digital Input 4
%
%
% samplingfrequency....Sampling Frequency of g.MOBIlab in Hz
% version....BIN file version (1.1,2.0,2.1...g.MOBIlab, 3.0...g.MOBIlab+)
% lowpass....lowpass frequency in Hz
% highpass....highpass frequency in Hz
% sens....sensitivity for g.MOBIlab channels in uV
% manu....manufacturer of device
% prodname....product name
%
% Author:   Maresch
% Last modified: Maresch-2008.11.10
%
% Version 3.0
% (c) 2009 g.tec medical engineering GmbH


fid=fopen(filename, 'rb');

% read in the relevant header information
i=1;
manu = fgetl(fid);
str = manu;

% if header exists, find end of header
while ~strncmp(str(i,:),'EOH',3)
    str = strvcat(str,fgetl(fid));
    i=i+1;
end
prodname=deblank(str(2,:));
version=deblank(str(3,:));
samplingfrequency=str2num(str(4,:));
coding=str(5,:);
channelsonscreen=str(6,:);

% read values
% check the number of data columns
% one column for each channel (1 to 8) one column for all digital values
noc = 0;    % number of colums in data array
y = [];     % if only digital channels are recorded y becomes type 
            % uint16 -> we create a empty y here to overcome this
            % error
%Analog Channel 1
if str(5,8)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(10,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 2
if str(5,7)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(11,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 3
if str(5,6)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(12,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 4
if str(5,5)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(13,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 5
if str(5,4)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(14,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 6
if str(5,3)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(15,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 7
if str(5,2)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(16,:),'%f %f %f %f %c','delimiter','/');
end
%Analog Channel 8
if str(5,1)=='1'
    noc = noc+1;
    [highpass(1,noc),lowpass(1,noc),sens(1,noc),sample,pol(1,noc)]...
        = strread(str(17,:),'%f %f %f %f %c','delimiter','/');
end
% DIO (any)
if any(str2num(str(5,9:16)))
    noc = noc+1;
end

data = (fread(fid,[noc,inf],'int16'))';
%data = data';
fclose(fid);
        
dataindex = 1;
        
%factor to transform analog channel data from int16 to uV values
factor = (2*5)/(4*65536);

if str(5,8)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,7)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,6)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,5)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,4)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,3)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,2)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

if str(5,1)=='1'
    y(:,dataindex) = data(:,dataindex) * factor * sens(1,dataindex);
    dataindex = dataindex + 1;
end

        
% check digital inputs/outputs
if any(str2num(str(5,9:16)))
    tmp = data(:,dataindex);
    tmp = uint16(tmp);
    if str(5,16)=='1'
        y(:,dataindex) = bitget(tmp,1);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,15)=='1'
        y(:,dataindex) = bitget(tmp,4);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,14)=='1'
        y(:,dataindex) = bitget(tmp,2);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,13)=='1'
        y(:,dataindex) = bitget(tmp,3);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
    dataindex = dataindex + 1;
    end
    if str(5,12)=='1'
        y(:,dataindex) = bitget(tmp,5);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,11)=='1'
        y(:,dataindex) = bitget(tmp,6);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,10)=='1'
        y(:,dataindex) = bitget(tmp,7);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
    if str(5,9)=='1'
        y(:,dataindex) = bitget(tmp,8);
        y(:,dataindex) = y(:,dataindex)*5000000;
        lowpass(1,dataindex) = 0; highpass(1,dataindex) = 0; sens(1,dataindex) = 5;
        dataindex = dataindex + 1;
    end
end
end

