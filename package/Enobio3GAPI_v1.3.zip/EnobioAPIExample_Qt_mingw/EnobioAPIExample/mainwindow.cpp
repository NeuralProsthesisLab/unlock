#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QDate>
#include <QDebug>

#include "channeldata.h"
#include "processeddata.h"
#include "StatusData.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    // The consumers are registeres into the Enobio processor in order to
    // receive data, power and status
    _enobio.registerConsumer(Enobio3G::ENOBIO_DATA, _enobioDataConsumer);
    _enobio.registerConsumer(Enobio3G::STATUS, _enobioStatusConsumer);
    _enobio.registerConsumer(Enobio3G::ACCELEROMETER,
                             _enobioAccelerometerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_DELTA, _deltaPowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_THETA, _thetaPowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_ALPHA, _alphaPowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_BETA, _betaPowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_GAMMA, _gammaPowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_USERDEFINED_1,
                             _userDefined1PowerConsumer);
    _enobio.registerConsumer(Enobio3G::POWER_USERDEFINED_2,
                             _userDefined2PowerConsumer);

    // Get the data from the accelerometer
    _enobio.activateAccelerometer(true);

    // Configure power bands
    _enobio.setUserDefinedBand1(0.0,100.0);
    _enobio.setUserDefinedBand2(20.0,50.0);
    _enobio.setPowerCalculationRate(500);
    _enobio.setPowerComputingLength(2500);

    // Configure power band combinations
    // Valence: F3 on Alpha - F4 on Alpha
    // Supposing channel 1 placed on F3 and channels 2 placed on F4
    _enobio.configurePowerCombinationFeatures(0, // configuring first feature
                                              2, // alpha band
                                              0x01, // only first channel
                                              2, // substraction
                                              2, // alpha band
                                              0x02, // only second channel
                                              0); // No normalization

    // Registering of the Consumer to receive data from the power combination
    // features
    _enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_0,
                                                            _feature0Consumer);
    _enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_1,
                                                            _feature1Consumer);
    _enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_2,
                                                            _feature2Consumer);
    _enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_3,
                                                            _feature3Consumer);
    _enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_4,
                                                            _feature4Consumer);

    // The consumers signals every time they receive new data and status so
    // their signals are directly connected to the TextEdit in the GUI
    QObject::connect(&_enobioDataConsumer, SIGNAL(newData(QString)),
                    ui->dataTextEdit, SLOT(append(QString)));
    QObject::connect(&_enobioStatusConsumer, SIGNAL(newStatus(QString)),
                    ui->statusTextEdit, SLOT(append(QString)));
    QObject::connect(&_enobioAccelerometerConsumer, SIGNAL(newData(QString)),
                     ui->accelerometerTextEdit, SLOT(setText(QString)));
    QObject::connect(&_deltaPowerConsumer, SIGNAL(newPower(QString)),
                    ui->deltaTextEdit, SLOT(setText(QString)));
    QObject::connect(&_thetaPowerConsumer, SIGNAL(newPower(QString)),
                    ui->thetaTextEdit, SLOT(setText(QString)));
    QObject::connect(&_alphaPowerConsumer, SIGNAL(newPower(QString)),
                    ui->alphaTextEdit, SLOT(setText(QString)));
    QObject::connect(&_betaPowerConsumer, SIGNAL(newPower(QString)),
                    ui->betaTextEdit, SLOT(setText(QString)));
    QObject::connect(&_gammaPowerConsumer, SIGNAL(newPower(QString)),
                    ui->gammaTextEdit, SLOT(setText(QString)));
    QObject::connect(&_userDefined1PowerConsumer, SIGNAL(newPower(QString)),
                    ui->userDefined1TextEdit, SLOT(setText(QString)));
    QObject::connect(&_userDefined2PowerConsumer, SIGNAL(newPower(QString)),
                    ui->userDefined2TextEdit, SLOT(setText(QString)));
    QObject::connect(&_feature0Consumer, SIGNAL(newPowerFeature(QString)),
                     ui->feature0TextEdit, SLOT(setText(QString)));
    QObject::connect(&_feature1Consumer, SIGNAL(newPowerFeature(QString)),
                     ui->feature1TextEdit, SLOT(setText(QString)));
    QObject::connect(&_feature2Consumer, SIGNAL(newPowerFeature(QString)),
                     ui->feature2TextEdit, SLOT(setText(QString)));
    QObject::connect(&_feature3Consumer, SIGNAL(newPowerFeature(QString)),
                     ui->feature3TextEdit, SLOT(setText(QString)));
    QObject::connect(&_feature4Consumer, SIGNAL(newPowerFeature(QString)),
                     ui->feature4TextEdit, SLOT(setText(QString)));

    //_enobio.setDemoMode(true, "demosignals.txt");
}

MainWindow::~MainWindow()
{
    _enobio.closeDevice();
    delete ui;
}


//
// Implementation of the receiveData for both Data and Status consumers
// The execution of these methods happens in a thread created by the Enobio
// instance so accesing GUI resources might lead to a program crash
//
void EnobioDataConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ChannelData * pData = (ChannelData *)data.getData();
    // Provide the data to whatever slot is connected to that signal
    emit newData(QString::number(pData->data()[0]) + "\t" +
                 QString::number(pData->data()[1]) + "\t" +
                 QString::number(pData->data()[2]) + "\t" +
                 QString::number(pData->data()[3]) + "\t" +
                 QString::number(pData->data()[4]) + "\t" +
                 QString::number(pData->data()[5]) + "\t" +
                 QString::number(pData->data()[6]) + "\t" +
                 QString::number(pData->data()[7]) + "\t" +
                 QString::number(pData->timestamp()));

    //qDebug()<<"New data main window" << endl;
}

void EnobioStatusConsumer::receiveData(const PData &data)
{
    StatusData * pStatus = (StatusData *)data.getData();
    // Provide the data to whatever slot is connected to that signal
    emit newStatus(QDate::currentDate().toString("dd/MM/yyyy") + " " +
                   QTime::currentTime().toString("hh:mm:ss") + " " +
                   QString::fromStdString(StatusData::getTypeFromCode(pStatus->getCode())) +
                   ": " + QString::fromStdString(pStatus->getString()));
}

void EnobioAccelerometerConsumer::receiveData (const PData &data)
{
    ChannelData * pData = (ChannelData *)data.getData();
    emit newData(QString::number(pData->data()[0]) + "\t" +
                 QString::number(pData->data()[1]) + "\t" +
                 QString::number(pData->data()[2]) + "\t" +
                 QString::number(pData->timestamp()));
}

void EnobioPowerConsumer::receiveData(const PData &data)
{
    ProcessedData * pPower = (ProcessedData *)data.getData();
    // Provide the data to whatever slot is connected to that signal
    emit newPower(QString::number(pPower->data()[0]) + "\t" +
                 QString::number(pPower->data()[1]) + "\t" +
                 QString::number(pPower->data()[2]) + "\t" +
                 QString::number(pPower->data()[3]) + "\t" +
                 QString::number(pPower->data()[4]) + "\t" +
                 QString::number(pPower->data()[5]) + "\t" +
                 QString::number(pPower->data()[6]) + "\t" +
                 QString::number(pPower->data()[7]) + "\t" +
                 QString::number(pPower->timestamp()));

    //qDebug()<<"New power main window" << endl;
}

void EnobioFeatureConsumer::receiveData(const PData &data)
{
    ProcessedData * pPowerFeature = (ProcessedData *)data.getData();
    emit newPowerFeature(QString::number(pPowerFeature->data()[0]));
}

void MainWindow::on_openCloseEnobioButton_toggled(bool checked)
{
    if (checked)
    {
        // mac address -> 00:07:80:XX:YY:ZZ
        unsigned char mac[6];
        mac[5] = 0x00;
        mac[4] = 0x07;
        mac[3] = 0x80;
        mac[2] = 0x4C;
        mac[1] = 0x0F;
        mac[0] = 0x1C;

        if(_enobio.openDevice(mac))
        {
            ui->openCloseEnobioButton->setText("Close Enobio");
        }
        else
        {
            QMessageBox::information(this, "EnobioAPI demo",
                                     "Error opening Enobio. Check it is "
                                     "plugged to the computer");
        }
    }
    else
    {
        ui->openCloseEnobioButton->setText("Open Enobio");
        _enobio.closeDevice();
    }
}

void MainWindow::on_startStopEEGButton_toggled(bool checked)
{
    if (checked)
    {
        ui->startStopEEGButton->setText("Stop EEG");
        _enobio.startStreaming();
    }
    else
    {
        ui->startStopEEGButton->setText("Start EEG");
        _enobio.stopStreaming();
    }
}
