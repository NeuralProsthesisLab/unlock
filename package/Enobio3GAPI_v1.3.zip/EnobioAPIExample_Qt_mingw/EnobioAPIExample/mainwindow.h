#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>

//#include "Enobio.h"
#include "enobio3g.h"


namespace Ui {
    class MainWindow;
}


//
// Definition of the consumers to receive both data and status from Enobio
//

class EnobioPowerConsumer : public QObject, public IDataConsumer
{
    Q_OBJECT
public:
    void receiveData (const PData& data);
signals:
    void newPower(QString stringPower);
};

class EnobioDataConsumer : public QObject, public IDataConsumer
{
    Q_OBJECT
public:
    void receiveData (const PData& data);
signals:
    void newData (QString stringData);
};

class EnobioStatusConsumer : public QObject, public IDataConsumer
{
    Q_OBJECT
public:
    void receiveData (const PData& data);
signals:
    void newStatus (QString stringStatus);
};

class EnobioAccelerometerConsumer : public QObject, public IDataConsumer
{
    Q_OBJECT
public:
    void receiveData (const PData& data);
signals:
    void newData (QString stringData);
};

class EnobioFeatureConsumer : public QObject, public IDataConsumer
{
    Q_OBJECT
public:
    void receiveData (const PData &data);
signals:
    void newPowerFeature (QString stringPowerFeature);
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    //
    // Declaration of Enobio and consumers
    //
    Enobio3G _enobio;
    EnobioDataConsumer _enobioDataConsumer;
    EnobioStatusConsumer _enobioStatusConsumer;
    EnobioAccelerometerConsumer _enobioAccelerometerConsumer;
    EnobioPowerConsumer _deltaPowerConsumer;
    EnobioPowerConsumer _thetaPowerConsumer;
    EnobioPowerConsumer _alphaPowerConsumer;
    EnobioPowerConsumer _betaPowerConsumer;
    EnobioPowerConsumer _gammaPowerConsumer;
    EnobioPowerConsumer _userDefined1PowerConsumer;
    EnobioPowerConsumer _userDefined2PowerConsumer;
    EnobioFeatureConsumer _feature0Consumer;
    EnobioFeatureConsumer _feature1Consumer;
    EnobioFeatureConsumer _feature2Consumer;
    EnobioFeatureConsumer _feature3Consumer;
    EnobioFeatureConsumer _feature4Consumer;

private slots:
    void on_startStopEEGButton_toggled(bool checked);
    void on_openCloseEnobioButton_toggled(bool checked);
};

#endif // MAINWINDOW_H
