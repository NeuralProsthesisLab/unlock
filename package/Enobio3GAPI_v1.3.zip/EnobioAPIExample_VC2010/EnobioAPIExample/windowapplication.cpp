#include <windows.h>
#include <string.h>
#include <stdio.h>

#include "Enobio3G.h"
#include "channeldata.h"
#include "processeddata.h"
#include "StatusData.h"

#define ID_OPEN_CLOSE_ENOBIO_BUTTON 1
#define ID_START_STOP_EEG_BUTTON 2
#define ID_ENOBIO_DATA_EDIT 3
#define ID_ENOBIO_STATUS_EDIT 4

//
// User defined messages
//
#define WM_UPDATE_ENOBIODATA	                (WM_USER + 0)
#define WM_UPDATE_STATUSDATA	                (WM_USER + 1)
#define WM_UPDATE_ENOBIODELTAPOWERDATA        (WM_USER + 2)
#define WM_UPDATE_ENOBIOTHETAPOWERDATA        (WM_USER + 3)
#define WM_UPDATE_ENOBIOALPHAPOWERDATA        (WM_USER + 4)
#define WM_UPDATE_ENOBIOBETAPOWERDATA         (WM_USER + 5)
#define WM_UPDATE_ENOBIOGAMMAPOWERDATA        (WM_USER + 6)
#define WM_UPDATE_ENOBIOSMRPOWERDATA          (WM_USER + 7)
#define WM_UPDATE_ENOBIOUSERDEFINED1POWERDATA (WM_USER + 8)
#define WM_UPDATE_ENOBIOUSERDEFINED2POWERDATA (WM_USER + 9)
#define WM_UPDATE_ENOBIOACCELEROMETERDATA     (WM_USER + 10)
#define WM_UPDATE_ENOBIOFEATUREPOWER0DATA     (WM_USER + 11)
#define WM_UPDATE_ENOBIOFEATUREPOWER1DATA     (WM_USER + 12)
#define WM_UPDATE_ENOBIOFEATUREPOWER2DATA     (WM_USER + 13)
#define WM_UPDATE_ENOBIOFEATUREPOWER3DATA     (WM_USER + 14)
#define WM_UPDATE_ENOBIOFEATUREPOWER4DATA     (WM_USER + 15)

//
// Definition of the consumers to receive both data and status from Enobio
//
class EnobioDataConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);

	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioStatusConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioAccelerometerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioDeltaPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioThetaPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioAlphaPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioBetaPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioGammaPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioSMRPowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioUserDefined1PowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioUserDefined2PowerConsumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioFeaturePower0Consumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioFeaturePower1Consumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioFeaturePower2Consumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioFeaturePower3Consumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

class EnobioFeaturePower4Consumer : public IDataConsumer
{
public:
    void receiveData (const PData& data);
	
	void setWindowHandler(HWND hWnd) {_hWnd = hWnd;}
private:
	HWND _hWnd;
};

//
// Implementation of the receiveData for both Data and Status consumers
// The execution of these methods happens in a thread created by the Enobio
// instance so accesing GUI resources might lead to a program crash
//
void EnobioDataConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ChannelData * pData = (ChannelData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%d %d %d %d %d %d %d %d %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIODATA, 0, (LPARAM)strMsg);
}

void EnobioStatusConsumer::receiveData(const PData &data)
{
    StatusData * pStatus = (StatusData *)data.getData();
    PostMessage(_hWnd, WM_UPDATE_STATUSDATA, (WPARAM)pStatus->getCode(), 0);
}

void EnobioAccelerometerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ChannelData * pData = (ChannelData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%d %d %d %lld",
                                          pData->data()[0],
                                          pData->data()[1],
                                          pData->data()[2],
                                          pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOACCELEROMETERDATA, 0, (LPARAM)strMsg);
}


void EnobioDeltaPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIODELTAPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioThetaPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOTHETAPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioAlphaPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOALPHAPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioBetaPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOBETAPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioGammaPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOGAMMAPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioSMRPowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOSMRPOWERDATA, 0, (LPARAM)strMsg);
}

void EnobioUserDefined1PowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOUSERDEFINED1POWERDATA, 0, (LPARAM)strMsg);
}

void EnobioUserDefined2PowerConsumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %lld",
                                                   pData->data()[0],
                                                   pData->data()[1],
                                                   pData->data()[2],
                                                   pData->data()[3],
                                                   pData->data()[4],
                                                   pData->data()[5],
                                                   pData->data()[6],
                                                   pData->data()[7],
                                                   pData->timestamp());
	PostMessage(_hWnd, WM_UPDATE_ENOBIOUSERDEFINED2POWERDATA, 0, (LPARAM)strMsg);
}

void EnobioFeaturePower0Consumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f",  pData->data()[0]);
	PostMessage(_hWnd, WM_UPDATE_ENOBIOFEATUREPOWER0DATA, 0, (LPARAM)strMsg);
}

void EnobioFeaturePower1Consumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f",  pData->data()[0]);
	PostMessage(_hWnd, WM_UPDATE_ENOBIOFEATUREPOWER1DATA, 0, (LPARAM)strMsg);
}

void EnobioFeaturePower2Consumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f",  pData->data()[0]);
	PostMessage(_hWnd, WM_UPDATE_ENOBIOFEATUREPOWER2DATA, 0, (LPARAM)strMsg);
}

void EnobioFeaturePower3Consumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f",  pData->data()[0]);
	PostMessage(_hWnd, WM_UPDATE_ENOBIOFEATUREPOWER3DATA, 0, (LPARAM)strMsg);
}

void EnobioFeaturePower4Consumer::receiveData(const PData &data)
{
    // The EnobioData is destroyed after the execution of receiveData by
    // the caller
    ProcessedData * pData = (ProcessedData *)data.getData();
    // This memory should be deallocated when the message is attended
    TCHAR * strMsg = new TCHAR[200]; 
    sprintf_s(strMsg, 200, "%.2f",  pData->data()[0]);
	PostMessage(_hWnd, WM_UPDATE_ENOBIOFEATUREPOWER4DATA, 0, (LPARAM)strMsg);
}

//
// Declaration of Enobio and consumers
//
Enobio3G enobio;
EnobioDataConsumer enobioDataConsumer;
EnobioStatusConsumer enobioStatusConsumer;
EnobioAccelerometerConsumer enobioAccelerometerConsumer;
EnobioDeltaPowerConsumer enobioDeltaPowerConsumer;
EnobioThetaPowerConsumer enobioThetaPowerConsumer;
EnobioAlphaPowerConsumer enobioAlphaPowerConsumer;
EnobioBetaPowerConsumer enobioBetaPowerConsumer;
EnobioGammaPowerConsumer enobioGammaPowerConsumer;
EnobioSMRPowerConsumer enobioSMRPowerConsumer;
EnobioUserDefined1PowerConsumer enobioUserDefined1PowerConsumer;
EnobioUserDefined2PowerConsumer enobioUserDefined2PowerConsumer;
EnobioFeaturePower0Consumer enobioFeaturePower0Consumer;
EnobioFeaturePower1Consumer enobioFeaturePower1Consumer;
EnobioFeaturePower2Consumer enobioFeaturePower2Consumer;
EnobioFeaturePower3Consumer enobioFeaturePower3Consumer;
EnobioFeaturePower4Consumer enobioFeaturePower4Consumer;


void appendToWindow (HWND hWnd, const char * message)
{
    int length;
    length = GetWindowTextLength(hWnd) + strlen(message) + 3;
    char * newMessage = new char[length];
    GetWindowText(hWnd, newMessage, length);
    strcat_s(newMessage, length, message);
    strcat_s(newMessage, length, "\r\n");
    SetWindowText(hWnd, newMessage);
    delete newMessage;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static HWND hwndOpenCloseButton;
    static HWND hwndStartStopButton;
    static HWND hwndDataEdit;
    static HWND hwndStatusEdit;
    static HWND hwndAccelerometerEdit;
    static HWND hwndDeltaPowerEdit;
    static HWND hwndThetaPowerEdit;
    static HWND hwndAlphaPowerEdit;
    static HWND hwndBetaPowerEdit;
    static HWND hwndGammaPowerEdit;
    static HWND hwndSMRPowerEdit;
    static HWND hwndUserDefined1PowerEdit;
    static HWND hwndUserDefined2PowerEdit;
    static HWND hwndFeaturePower0Edit;
    static HWND hwndFeaturePower1Edit;
    static HWND hwndFeaturePower2Edit;
    static HWND hwndFeaturePower3Edit;
    static HWND hwndFeaturePower4Edit;
    static int len;
    static char text[30];
    char * message;

    switch(msg)
    {
    case WM_CREATE:
        hwndOpenCloseButton = CreateWindow(TEXT("button"), TEXT("Open Enobio"),
                                           WS_VISIBLE | WS_CHILD, 10, 10, 100, 25,
                                           hwnd, (HMENU) ID_OPEN_CLOSE_ENOBIO_BUTTON, NULL, NULL);
        hwndStartStopButton = CreateWindow(TEXT("button"), TEXT("Start EEG"),
                                           WS_VISIBLE | WS_CHILD, 140, 10, 100, 25,
                                           hwnd, (HMENU) ID_START_STOP_EEG_BUTTON, NULL, NULL);

        CreateWindow(TEXT("static"), TEXT("Data"), WS_CHILD | WS_VISIBLE, 10, 40, 50, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndDataEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 60, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Status"), WS_CHILD | WS_VISIBLE, 10, 90, 50, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndStatusEdit = CreateWindow(TEXT("Edit"), NULL,
                                      WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                      ES_MULTILINE | ES_AUTOVSCROLL,
                                      30, 110, 700, 90, hwnd, (HMENU) ID_ENOBIO_STATUS_EDIT,
                                      NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Delta power"), WS_CHILD | WS_VISIBLE, 10, 200, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndDeltaPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 220, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Theta power"), WS_CHILD | WS_VISIBLE, 10, 250, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndThetaPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 270, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Alpha power"), WS_CHILD | WS_VISIBLE, 10, 300, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndAlphaPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 320, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Beta power"), WS_CHILD | WS_VISIBLE, 10, 350, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndBetaPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 370, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Gamma power"), WS_CHILD | WS_VISIBLE, 10, 400, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndGammaPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 420, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("SMR power"), WS_CHILD | WS_VISIBLE, 10, 450, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndSMRPowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 470, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("User-defined 1 power"), WS_CHILD | WS_VISIBLE, 10, 500, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndUserDefined1PowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 520, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("User-defined 2 power"), WS_CHILD | WS_VISIBLE, 10, 550, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndUserDefined2PowerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 570, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Accelerometer"), WS_CHILD | WS_VISIBLE, 10, 600, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndAccelerometerEdit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 620, 700, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        CreateWindow(TEXT("static"), TEXT("Power features"), WS_CHILD | WS_VISIBLE, 10, 650, 150, 25,
                     hwnd, (HMENU) 1, NULL, NULL);
        hwndFeaturePower0Edit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    30, 670, 120, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        hwndFeaturePower1Edit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    160, 670, 120, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        hwndFeaturePower2Edit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    290, 670, 120, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        hwndFeaturePower3Edit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    420, 670, 120, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);
        hwndFeaturePower4Edit = CreateWindow(TEXT("Edit"), NULL,
                                    WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_LEFT |
                                    ES_MULTILINE | ES_AUTOVSCROLL,
                                    550, 670, 120, 30, hwnd, (HMENU) ID_ENOBIO_DATA_EDIT,
                                    NULL, NULL);

        break;

    case WM_COMMAND:
        if (HIWORD(wParam) == BN_CLICKED) {
            switch(LOWORD(wParam))
            {
            case 1: // open / close Enobio
                GetWindowText(hwndOpenCloseButton, text, 30);
                if (strcmp(text, "Open Enobio") == 0)
                {
                  // mac address -> 00:07:80:XX:YY:ZZ
                  unsigned char mac[6];
                  mac[5] = 0x00;
                  mac[4] = 0x07;
                  mac[3] = 0x80;
                  mac[2] = 0x4C;
                  mac[1] = 0x0F;
                  mac[0] = 0x1C;
                  if (!enobio.openDevice(mac))
                  {
                    MessageBox(NULL, TEXT("Error opening Enobio. Check it is plugged to the computer"),
                      TEXT("EnobioAPI demo"), MB_OK);
                  }
                  else
                  {
                    SetWindowText(hwndOpenCloseButton, TEXT("Close Enobio"));
                  }
                }
                else
                {
                  enobio.closeDevice();
                  SetWindowText(hwndOpenCloseButton, TEXT("Open Enobio"));
                }
                break;
            case 2: // start / stop EEG streaming
              GetWindowText(hwndStartStopButton, text, 30);
              if (strcmp(text, "Start EEG") == 0)
              {
                enobio.startStreaming();
                SetWindowText(hwndStartStopButton, TEXT("Stop EEG"));
              }
              else
              {
                enobio.stopStreaming();
                SetWindowText(hwndStartStopButton, TEXT("Start EEG"));
              }
              break;
            }
        }
        break;

    case WM_DESTROY:
        enobio.closeDevice();
        PostQuitMessage(0);
	break;

	case WM_UPDATE_ENOBIODATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndDataEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

	case WM_UPDATE_STATUSDATA: // new Status data received
        appendToWindow(hwndStatusEdit,
                       StatusData::getStringFromCode((StatusData::statusCode)wParam));
		break;

  case WM_UPDATE_ENOBIOACCELEROMETERDATA: // new Accelerometer data received
        message = (char*)lParam;
        SetWindowText(hwndAccelerometerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIODELTAPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndDeltaPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOTHETAPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndThetaPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOALPHAPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndAlphaPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOBETAPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndBetaPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOGAMMAPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndGammaPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOSMRPOWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndSMRPowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;

  case WM_UPDATE_ENOBIOUSERDEFINED1POWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndUserDefined1PowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOUSERDEFINED2POWERDATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndUserDefined2PowerEdit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOFEATUREPOWER0DATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndFeaturePower0Edit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOFEATUREPOWER1DATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndFeaturePower1Edit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOFEATUREPOWER2DATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndFeaturePower2Edit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOFEATUREPOWER3DATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndFeaturePower3Edit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
  case WM_UPDATE_ENOBIOFEATUREPOWER4DATA: // new Enobio data received
        message = (char*)lParam;
        SetWindowText(hwndFeaturePower4Edit, message);
        // The message shall be deallocated since it was dinamically created
        // when the data was received
        delete message;
		break;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow )
{
    MSG  msg ;    
    WNDCLASS wc = {0};
    wc.lpszClassName = TEXT( "Enobio API example" );
    wc.hInstance     = hInstance ;
    wc.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
    wc.lpfnWndProc   = WndProc ;
    wc.hCursor       = LoadCursor(0,IDC_ARROW);
    
    RegisterClass(&wc);
    HWND hWnd = CreateWindow( wc.lpszClassName, TEXT("Enobio API example"),
                              WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                              220, 220, 750, 760, 0, 0, hInstance, 0);
    
    // The consumer shall knwo the handle of the main window in order to
    // notify that new data or status has been received
    enobioDataConsumer.setWindowHandler(hWnd);
    enobioStatusConsumer.setWindowHandler(hWnd);
    enobioAccelerometerConsumer.setWindowHandler(hWnd);
    enobioDeltaPowerConsumer.setWindowHandler(hWnd);
    enobioThetaPowerConsumer.setWindowHandler(hWnd);
    enobioAlphaPowerConsumer.setWindowHandler(hWnd);
    enobioBetaPowerConsumer.setWindowHandler(hWnd);
    enobioGammaPowerConsumer.setWindowHandler(hWnd);
    enobioSMRPowerConsumer.setWindowHandler(hWnd);
    enobioUserDefined1PowerConsumer.setWindowHandler(hWnd);
    enobioUserDefined2PowerConsumer.setWindowHandler(hWnd);
    enobioFeaturePower0Consumer.setWindowHandler(hWnd);
    enobioFeaturePower1Consumer.setWindowHandler(hWnd);
    enobioFeaturePower2Consumer.setWindowHandler(hWnd);
    enobioFeaturePower3Consumer.setWindowHandler(hWnd);
    enobioFeaturePower4Consumer.setWindowHandler(hWnd);
    // The consumers are registereds into the Enobio processor in order to
    // receive both data and status
    enobio.registerConsumer(Enobio3G::ENOBIO_DATA, enobioDataConsumer);
    enobio.registerConsumer(Enobio3G::STATUS, enobioStatusConsumer);
    enobio.registerConsumer(Enobio3G::ACCELEROMETER, enobioAccelerometerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_DELTA, enobioDeltaPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_THETA, enobioThetaPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_ALPHA, enobioAlphaPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_BETA, enobioBetaPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_GAMMA, enobioGammaPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_SMR, enobioSMRPowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_USERDEFINED_1, enobioUserDefined1PowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_USERDEFINED_2, enobioUserDefined2PowerConsumer);
    enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_0, enobioFeaturePower0Consumer);
    enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_1, enobioFeaturePower1Consumer);
    enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_2, enobioFeaturePower2Consumer);
    enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_3, enobioFeaturePower3Consumer);
    enobio.registerConsumer(Enobio3G::POWER_COMBINATION_FEATURE_4, enobioFeaturePower4Consumer);
    
    enobio.setUserDefinedBand1(0.0,100.0);
    enobio.setUserDefinedBand2(20.0,50.0);
    enobio.setPowerCalculationRate(500);
    enobio.setPowerComputingLength(2500);

    // Configure power band combinations
    // Valence: F3 on Alpha - F4 on Alpha
    // Supposing channel 1 placed on F3 and channels 2 placed on F4
    enobio.configurePowerCombinationFeatures(0, // configuring first feature
                                             Enobio3G::ALPHA_BAND,//2, // alpha band
                                             0x01, // only first channel
                                             Enobio3G::SUBTRACTION_OPERATION, // substraction
                                             Enobio3G::ALPHA_BAND, // alpha band
                                             0x02, // only second channel
                                             Enobio3G::NO_NORMALIZATION); // No normalization

    // Get the data from the accelerometer
    enobio.activateAccelerometer(true);

    //enobio.setDemoMode(true, "demosignals.txt");

    while( GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int) msg.wParam;
}
