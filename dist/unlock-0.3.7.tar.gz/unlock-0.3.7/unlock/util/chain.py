
class BaseChain(object):
    def __init__(self):
        self.dispatcher = dispatcher.Signal(providing_args=['next'])
    def signal(self):
        pass

class ChainList(BaseChain):
    def __init__(self):
        pass
    def set_next(self, next_in_chain):
        pass
    def signal(self, command):
        pass
    
class TreeChain(BaseChain):
    def __init__(self):
        pass
    def add_child(self):
        pass
    def signal(self):
        pass