from sklearn import datasets
import cPickle

iris = datasets.load_iris()
digits = datasets.load_digits()

class UnlockClassifierMixin(object):
    def __init__(self):
        pass
        
    @staticmethod
    def serialize(unserialized_object):
        serialized_object = cPickle.dump(unserialized_object)
        return serialized_object
        
    @staticmethod
    def deserialize(serialized_object):
        deserialized_object = cPickle.load(serialized_object)
        return deserialized_object
    
# save the classifier
#with open('my_dumped_classifier.pkl', 'wb') as fid:
#    cPickle.dump(gnb, fid)    

# load it again
#with open('my_dumped_classifier.pkl', 'rb') as fid:
#    gnb_loaded = cPickle.load(fid)
    

